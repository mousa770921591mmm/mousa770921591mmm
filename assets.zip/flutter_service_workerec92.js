'use strict';
const MANIFEST = 'flutter-app-manifest';
const TEMP = 'flutter-temp-cache';
const CACHE_NAME = 'flutter-app-cache';
const RESOURCES = {
  "version.json": "652356fbe3cec18c0f22c86c32670e76",
"index.html": "6d8b63262e36f5bfb7e58f595b95f2e3",
"/": "6d8b63262e36f5bfb7e58f595b95f2e3",
"firebase-messaging-sw.js": "86226911e19afada9712ee7379c8e08c",
"main.dart.js": "3dc8015cf67d8a7e592719f19e57495b",
"favicon.png": "5dcef449791fa27946b3d35ad8803796",
"icons/Icon-192.png": "ac9a721a12bbc803b44f645561ecb1e1",
"icons/Icon-512.png": "96e752610906ba2a93c65f8abe1645f1",
"manifest.json": "53218ed90c0c27d900232859b9291819",
"assets/AssetManifest.json": "0d6985baf00f6fd642cc62930ee0cdcb",
"assets/NOTICES": "57b5bdc7d7f00b31e845ebfbd10086da",
"assets/FontManifest.json": "2b66a9bc0fd33f3f5ecc7b2a2b35ea81",
"assets/packages/cupertino_icons/assets/CupertinoIcons.ttf": "6d342eb68f170c97609e9da345464e5e",
"assets/fonts/MaterialIcons-Regular.otf": "4e6447691c9509f7acdbf8a931a85ca1",
"assets/assets/images/googleplay.png": "ef2f5c95483977062d05f039237b503d",
"assets/assets/images/ymobile.png": "5989e0d49021b5a7c0accb4413388219",
"assets/assets/images/why.png": "17bcc74d178e770b267b0d248d56da02",
"assets/assets/images/appstore.png": "c1a705b1230945833923b6f03c718375",
"assets/assets/images/transfer.png": "027412a299cd2cabe839f07d27ead1f8",
"assets/assets/images/mtn.png": "6bf40b23690bbf7e335edcb3acf810e6",
"assets/assets/images/freefire.jpg": "de546d1f2f465e0e602b334345d6c54d",
"assets/assets/images/netflix.png": "5eecb6113e4695bc422b5f7f82e2d5a2",
"assets/assets/images/adenet.png": "6246ff8d487c0bf9fdf4fdcc3e3745d7",
"assets/assets/images/logo.jpg": "903b8957e98ee1586139d19986dde505",
"assets/assets/images/adsl.png": "ea98ade2a6bbdc85dcc0f4bcaa490ca1",
"assets/assets/images/sabaphone.png": "edeecaeca8f93bf9cf92b59b41ca13b1",
"assets/assets/images/pubg.jpg": "7e588ea550a2c2bed528ac64822fd937",
"assets/assets/images/noimg.jpg": "28868fe496888d240411d3564c33ce83",
"assets/assets/images/line.jpg": "1eb49c645809c475d28e39b4f595d7ff",
"assets/assets/images/beinsport.png": "da80faaa0d873f5c7090e3f466228149",
"assets/assets/html/sanad.html": "747a2eb25034392dd2b1b3d9e66728d1",
"assets/assets/sounds/solfa.mp3": "15a8724643156bce7b0e4e1783fff5c4",
"assets/assets/sounds/nosolfa.mp3": "3490f615fdaff2abfa6a8cdfb12c20c1",
"assets/assets/sounds/successpaid.mp3": "63211a27253f1952b815aaba7a2205a4",
"assets/assets/sounds/cong.mp3": "8472324a37313118128be6291a1215dd",
"assets/assets/fonts/Hacen_Algeria-Medium.ttf": "ebc487adedf405f8493d2a8f97871802",
"assets/assets/fonts/Almarai-Light.ttf": "484f968404893edf87a29965d05711d3"
};

// The application shell files that are downloaded before a service worker can
// start.
const CORE = [
  "/",
"main.dart.js",
"index.html",
"assets/NOTICES",
"assets/AssetManifest.json",
"assets/FontManifest.json"];
// During install, the TEMP cache is populated with the application shell files.
self.addEventListener("install", (event) => {
  self.skipWaiting();
  return event.waitUntil(
    caches.open(TEMP).then((cache) => {
      return cache.addAll(
        CORE.map((value) => new Request(value, {'cache': 'reload'})));
    })
  );
});

// During activate, the cache is populated with the temp files downloaded in
// install. If this service worker is upgrading from one with a saved
// MANIFEST, then use this to retain unchanged resource files.
self.addEventListener("activate", function(event) {
  return event.waitUntil(async function() {
    try {
      var contentCache = await caches.open(CACHE_NAME);
      var tempCache = await caches.open(TEMP);
      var manifestCache = await caches.open(MANIFEST);
      var manifest = await manifestCache.match('manifest');
      // When there is no prior manifest, clear the entire cache.
      if (!manifest) {
        await caches.delete(CACHE_NAME);
        contentCache = await caches.open(CACHE_NAME);
        for (var request of await tempCache.keys()) {
          var response = await tempCache.match(request);
          await contentCache.put(request, response);
        }
        await caches.delete(TEMP);
        // Save the manifest to make future upgrades efficient.
        await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
        return;
      }
      var oldManifest = await manifest.json();
      var origin = self.location.origin;
      for (var request of await contentCache.keys()) {
        var key = request.url.substring(origin.length + 1);
        if (key == "") {
          key = "/";
        }
        // If a resource from the old manifest is not in the new cache, or if
        // the MD5 sum has changed, delete it. Otherwise the resource is left
        // in the cache and can be reused by the new service worker.
        if (!RESOURCES[key] || RESOURCES[key] != oldManifest[key]) {
          await contentCache.delete(request);
        }
      }
      // Populate the cache with the app shell TEMP files, potentially overwriting
      // cache files preserved above.
      for (var request of await tempCache.keys()) {
        var response = await tempCache.match(request);
        await contentCache.put(request, response);
      }
      await caches.delete(TEMP);
      // Save the manifest to make future upgrades efficient.
      await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
      return;
    } catch (err) {
      // On an unhandled exception the state of the cache cannot be guaranteed.
      console.error('Failed to upgrade service worker: ' + err);
      await caches.delete(CACHE_NAME);
      await caches.delete(TEMP);
      await caches.delete(MANIFEST);
    }
  }());
});

// The fetch handler redirects requests for RESOURCE files to the service
// worker cache.
self.addEventListener("fetch", (event) => {
  if (event.request.method !== 'GET') {
    return;
  }
  var origin = self.location.origin;
  var key = event.request.url.substring(origin.length + 1);
  // Redirect URLs to the index.html
  if (key.indexOf('?v=') != -1) {
    key = key.split('?v=')[0];
  }
  if (event.request.url == origin || event.request.url.startsWith(origin + '/#') || key == '') {
    key = '/';
  }
  // If the URL is not the RESOURCE list then return to signal that the
  // browser should take over.
  if (!RESOURCES[key]) {
    return;
  }
  // If the URL is the index.html, perform an online-first request.
  if (key == '/') {
    return onlineFirst(event);
  }
  event.respondWith(caches.open(CACHE_NAME)
    .then((cache) =>  {
      return cache.match(event.request).then((response) => {
        // Either respond with the cached resource, or perform a fetch and
        // lazily populate the cache.
        return response || fetch(event.request).then((response) => {
          cache.put(event.request, response.clone());
          return response;
        });
      })
    })
  );
});

self.addEventListener('message', (event) => {
  // SkipWaiting can be used to immediately activate a waiting service worker.
  // This will also require a page refresh triggered by the main worker.
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
    return;
  }
  if (event.data === 'downloadOffline') {
    downloadOffline();
    return;
  }
});

// Download offline will check the RESOURCES for all files not in the cache
// and populate them.
async function downloadOffline() {
  var resources = [];
  var contentCache = await caches.open(CACHE_NAME);
  var currentContent = {};
  for (var request of await contentCache.keys()) {
    var key = request.url.substring(origin.length + 1);
    if (key == "") {
      key = "/";
    }
    currentContent[key] = true;
  }
  for (var resourceKey of Object.keys(RESOURCES)) {
    if (!currentContent[resourceKey]) {
      resources.push(resourceKey);
    }
  }
  return contentCache.addAll(resources);
}

// Attempt to download the resource online before falling back to
// the offline cache.
function onlineFirst(event) {
  return event.respondWith(
    fetch(event.request).then((response) => {
      return caches.open(CACHE_NAME).then((cache) => {
        cache.put(event.request, response.clone());
        return response;
      });
    }).catch((error) => {
      return caches.open(CACHE_NAME).then((cache) => {
        return cache.match(event.request).then((response) => {
          if (response != null) {
            return response;
          }
          throw error;
        });
      });
    })
  );
}
